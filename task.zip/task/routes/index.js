var express = require('express');
var router = express.Router();
var userdata=require('./userSchema');
var controllers=require('./controllers');
/* GET home page. */




module.exports = router;
module.exports = controllers;

