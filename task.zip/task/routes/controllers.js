var express = require('express');
const router = express.Router();
var mongoose = require('mongoose');
var userdata=require('./userSchema');

router.get('/', function(req, res, next) {
    res.render('index');
  });

  //adding new user
  router.post('/User',function(req,res){
    var user= new userdata({
      name:req.body.name,
      age: req.body.age,
      contact:{
        mobile: req.body.mobile,
        email: req.body.email
      },
      address: {
        street:req.body.street,
        city: req.body.city,
        state: req.body.state,
        pincode: req.body.pincode
      }
    }
    );
  user.save(function(err,result){
  if (err ){
  res.send(err);
  
  }else{
  console.log("hii");
  res.send(result);
  }
  
  })
})
//gesting all data
  router.get('/all',function(req,res,next){
    userdata.find({},function(err,result){
      if(err){
        res.send(err);
      }else{
        res.send(result);
  
      }
    })
  })
//finding one user by id
  router.get('/oneuser/:id',function(req,res,next){
    var data=req.params.id;
    userdata.findOne({"_id":data},function(err,result){
      if(err){
        res.send(err);
      }else{
        res.send(result);
  
      }
    })
  })
   //Update one user by id 
  router.put('/update/:id',function(req,res,next){
  
    var id=req.params.id;
    const data=req.body;
    console.log(id);
    console.log(data);
    userdata.findByIdAndUpdate({"_id":id},{$set:data},function(err,result){
      
      if(err){
        res.send(err);
      }else{
        res.send(result);
      }
    })
  })
  //deleting one user by id
  router.delete('/delete/:id',function(req,res,next){
 
    userdata.findByIdAndDelete({"_id":req.params.id},function(err,result){
      if(err){
        res.send(err);
      }else{
        res.send(result);
        console.log("data deleted");
      }
    })
    
    })
  
  
  module.exports = router;