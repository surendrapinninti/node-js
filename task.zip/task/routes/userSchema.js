
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
let dev_db_url = 'mongodb://suru:suru1997@ds149132.mlab.com:49132/surudb';
let mongoDB = process.env.MONGODB_URI || dev_db_url;
mongoose.connect(mongoDB);
mongoose.Promise = global.Promise;
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
var Schema = mongoose.Schema;
var userdata= new Schema({
  
    name: {
      type: String,
        unique : false,
        required : false
    },
    age: {
      type: Number,
        unique : false,
        required : false
    },
    contact: {
      mobile: {
        type: Number,
        unique : false,
        required : false
      },
      email:{
        type: String,
        unique : false,
        required : false
      }
    },
    address: {
      street:{
        type: String,
        unique : false,
        required : false
      },
      city: {
        type: String,
        unique : false,
        required : false
      },
      state: {
        type: String,
        unique : false,
        required : false
      },
      pincode: {
        type: Number,
        unique : false,
        required : false
      }
    }
  
  
});
module.exports = mongoose.model("userdata",userdata);